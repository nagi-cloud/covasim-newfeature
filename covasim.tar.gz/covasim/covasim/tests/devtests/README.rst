Devtests
========

This folder contains tests that are useful checks during development, but are not critical so are not part of CI. Note: they are **not** actively maintained, and are not guaranteed to all run with any given version of Covasim.