======================
Diamond Princess model
======================

This folder contains codes and tests for the first (unpublished) application of Covasim, which was to the *Diamond Princess* cruise ship. It illustrates how Covasim can be adapted to particular contexts, as well as showing how it has evolved since its initial creation.