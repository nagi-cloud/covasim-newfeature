'''
Simplest possible Covasim usage example.
'''

import covasim as cv
sim = cv.Sim()
sim.run()
sim.plot()