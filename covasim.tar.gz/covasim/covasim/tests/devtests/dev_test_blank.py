'''
This is required so pytest doesn't raise an error saying that no tests were found.
'''

def test_blank():
    pass