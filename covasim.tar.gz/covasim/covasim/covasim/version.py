'''
Version and license information.
'''

__all__ = ['__version__', '__versiondate__', '__license__']

__version__ = '3.1.4'
__versiondate__ = '2022-10-22'
__license__ = f'Covasim {__version__} ({__versiondate__}) — © 2020-2022 by IDM'
