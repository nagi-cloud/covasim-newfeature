Regression
==========

This folder contains previous versions of the default parameters for Covasim. Although older versions of the parameters are not guaranteed to be compatible across versions, they may help explain differences between versions.